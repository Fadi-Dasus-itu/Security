package com.assignment.security;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.assignment.security.controller.BobController;
import com.assignment.security.model.ApiModel;
import com.assignment.security.service.AliceService;
import com.assignment.security.service.BobService;
import com.fasterxml.jackson.core.JsonProcessingException;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class SecurityApplicationTests {

    @Autowired
    BobController controller;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private BobService bobService;
    @Autowired
    private AliceService aliceService;

    private static final String URL = "http://localhost:8081/Alice/";


    @Test
    @DisplayName("Bob roll his dice successfully")
    void bobSendEncryptedMessageToAliceSuccessfully() throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException, InvalidKeySpecException, UnsupportedEncodingException, JsonProcessingException, SignatureException {
        //        -----------------------------
        //  Bob fetches Alice public key
        //        -----------------------------
        ResponseEntity<byte[]> getPKResponseEntity = fetchAlicePK();

        //        -----------------------------
        //Bob publishes his public key to Alice
        //        -----------------------------
        ResponseEntity<String> publishBobPKResponseEntity = publishBobKey();

        //        -----------------------------
        // Bob sign the message using his private key before sending it to Alice
        //        -----------------------------

        ResponseEntity<String> sendMessageResponseEntity = sendSignedEncryptedMessage();

        //        -----------------------------
        // Bob gets Alice Dice score
        //        -----------------------------
        ResponseEntity<ApiModel> getAliceScoreResponseEntity = fetchAliceDiceScore();


        //        -----------------------------
        // Bob sends Alice the AES key to encrypt his score
        //        -----------------------------
        ResponseEntity<String> sendAESResponseEntity = sendAESKeyToAlice();


        //assert
        //        -----------------------------
        assertEquals(HttpStatus.OK.value(), sendMessageResponseEntity.getStatusCodeValue());
        assertEquals(HttpStatus.OK.value(), getPKResponseEntity.getStatusCodeValue());
        assertEquals(HttpStatus.OK.value(), publishBobPKResponseEntity.getStatusCodeValue());
        assertEquals(HttpStatus.OK.value(), getAliceScoreResponseEntity.getStatusCodeValue());
        assertEquals(HttpStatus.OK.value(), sendAESResponseEntity.getStatusCodeValue());
        // verify the winner
        printTheWinner(aliceService.getAliceScore(), bobService.getBobScore());
    }

    private void printTheWinner(String aliceScore, String bobScore) {
        var aliceScoreInt = Integer.valueOf(aliceScore);
        var bobScoreInt = Integer.valueOf(bobScore);
        if (aliceScoreInt > bobScoreInt) {
            System.out.println("Alice Score is :" + aliceService.getAliceScore() + ", Bob Score is: " + bobService.getBobScore()+" the winner is Alice");
        } else if(aliceScoreInt < bobScoreInt){
            System.out.println("Alice Score is :" + aliceService.getAliceScore() + ", Bob Score is: " + bobService.getBobScore()+" the winner is Bob");
        }
        else{
            System.out.println("there is no winner for this round, please try again");
        }
    }

    private ResponseEntity<String> sendAESKeyToAlice() throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException {
        ApiModel AESmodel = new ApiModel();
        var message = bobService.encryptMessage(aliceService.getPublicKey(), bobService.getSecret());
        AESmodel.setEncryptedMessage(message);
        return restTemplate.postForEntity(URL + "sendAESKey",
                AESmodel,
                String.class);
    }

    private ResponseEntity<ApiModel> fetchAliceDiceScore() throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException {
        ResponseEntity<ApiModel> getAliceScoreResponseEntity = restTemplate.getForEntity(URL + "getAliceDiceScore",
                ApiModel.class);
        var apiModel = getAliceScoreResponseEntity.getBody();
        var decryptedScore = bobService.decryptMessage(apiModel.getEncryptedMessage());
        var valid = bobService.verifySignature(apiModel, decryptedScore);
        aliceService.setAliceScore(decryptedScore);
        if (valid) {
            System.out.println(decryptedScore);
        }
        return getAliceScoreResponseEntity;
    }


    private ResponseEntity<byte[]> fetchAlicePK() throws NoSuchAlgorithmException, InvalidKeySpecException {
        ResponseEntity<byte[]> getPKResponseEntity = restTemplate.getForEntity(URL + "getAlicePublicKey",
                byte[].class);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(getPKResponseEntity.getBody());
        aliceService.setPublicKey(keyFactory.generatePublic(publicKeySpec));
        return getPKResponseEntity;
    }

    private ResponseEntity<String> publishBobKey() {
        return restTemplate.postForEntity(URL + "publishBobPK",
                bobService.getPublicKey().getEncoded(),
                String.class);
    }

    private ResponseEntity<String> sendSignedEncryptedMessage() throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException {

        String randomlyGeneratedScoreMessage = bobService.generateRandomDiceScore();

        ApiModel model = new ApiModel();
        var signature = bobService.signTheMessage(randomlyGeneratedScoreMessage);

        model.setEncryptedMessage(bobService.encryptMessage(aliceService.getPublicKey(), randomlyGeneratedScoreMessage));
        model.setDigitalSignature(signature);

        return restTemplate.postForEntity(URL + "sendEncryptedMessage",
                model,
                String.class);


    }

}

