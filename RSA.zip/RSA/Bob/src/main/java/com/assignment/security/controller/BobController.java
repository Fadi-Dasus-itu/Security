package com.assignment.security.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Bob")
public class BobController {


    @PostMapping("/publishAlicePK")
    public ResponseEntity<?> postDiceScore(@RequestBody String pk) {
        System.out.println(pk);
        return new ResponseEntity<>("received", HttpStatus.OK);
    }


    @PostMapping("/publishBobPK")
    public ResponseEntity<?> publishPK(@RequestBody String pk) {
        System.out.println(pk);
        return new ResponseEntity<>("received", HttpStatus.OK);
    }

    @PostMapping("/sendEncryptedMessage")
    public ResponseEntity<?> sendEncryptedMessage(@RequestBody String message) {
        System.out.println(message);
        return new ResponseEntity<>("received", HttpStatus.OK);
    }

    @PostMapping("/sendOneTimePadKey")
    public ResponseEntity<?> sendOneTimePadKey(@RequestBody String oneTimePadKey) {
        System.out.println(oneTimePadKey);
        return new ResponseEntity<>("received", HttpStatus.OK);
    }
}
