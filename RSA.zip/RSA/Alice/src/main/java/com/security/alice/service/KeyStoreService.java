package com.security.alice.service;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class KeyStoreService {


    private final AliceService aliceService;


    @Autowired
    public KeyStoreService(AliceService aliceService) {
        this.aliceService = aliceService;
    }

    @PostConstruct
    public void generateAliceKeys() throws NoSuchAlgorithmException {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        KeyPair pair = generator.generateKeyPair();
        aliceService.setPrivateKey(pair.getPrivate());
        aliceService.setPublicKey(pair.getPublic());
        System.out.println("Alice keys are generated successfully");
    }


}
