package com.security.alice.service;

import java.security.PublicKey;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Service
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BobService {
    private PublicKey publicKey;
    private String bobScore;
    private String oneTimePadKey;

}
