package com.security.alice.service;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SignatureException;
import java.util.Arrays;
import java.util.Random;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.security.alice.model.ApiModel;
import lombok.Getter;
import lombok.Setter;

@Service
@Getter
@Setter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AliceService implements Serializable {
    // Storing the key pair in memory is not always a good option, but it enough for this assignment
    private PrivateKey privateKey;
    private PublicKey publicKey;
    private final BobService bobService;
    private String AliceScore;

    @Autowired
    public AliceService(BobService bobService) {
        this.bobService = bobService;
    }


    public byte[] encryptMessage(String message) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        System.out.println("Alice encrypting the message using Bob public Key..........");
        Cipher encryptCipher = Cipher.getInstance("RSA");
        encryptCipher.init(Cipher.ENCRYPT_MODE, bobService.getPublicKey());
        byte[] secretMessageBytes = message.getBytes(StandardCharsets.UTF_8);
        byte[] encryptedMessageBytes = encryptCipher.doFinal(secretMessageBytes);
        // we send this over the API call
        System.out.println("the message is encrypted successfully");
        return encryptedMessageBytes;
    }


    public String decryptMessage(byte[] encryptedMessageBytes) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        System.out.println("decrypting the message.......");

        Cipher decryptCipher = Cipher.getInstance("RSA");
        decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] decryptedMessageBytes = decryptCipher.doFinal(encryptedMessageBytes);
        String decryptedMessage = new String(decryptedMessageBytes, StandardCharsets.UTF_8);


        System.out.println("the decrypted message is : Bob score: " + decryptedMessage);
        return decryptedMessage;

    }

    //    To check the digital signature, the message receiver generates a new hash from the received message,
    //    decrypts the received encrypted hash using the public key, and compares them. If they match, the Digital Signature is said to be verified.
    public Boolean verifySignature(ApiModel apiModel, String actualMessage) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
        System.out.println("verifying the digital signature");
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, bobService.getPublicKey());
        byte[] decryptedMessageHash = cipher.doFinal(apiModel.getDigitalSignature());

        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] newMessageHash = md.digest(actualMessage.getBytes(StandardCharsets.UTF_8));
        boolean isCorrect = Arrays.equals(decryptedMessageHash, newMessageHash);
        return isCorrect;
    }


    //    a digital signature is the encrypted hash (digest, checksum) of a message
    //    That means we generate a hash from a message and encrypt it with a private key according to a chosen algorithm
    //    The message, the encrypted hash, the corresponding public key, and the algorithm are all then sent.
    //    This is classified as a message with its digital signature.
    public byte[] signTheMessage(String message) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] messageHash = md.digest(message.getBytes(StandardCharsets.UTF_8));
        //        Encrypting the Generated Hash
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, privateKey);
        byte[] digitalSignature = cipher.doFinal(messageHash);
        System.out.println("Digital signature has been created successfully ......");
        return digitalSignature;

    }

    public String generateRandomDiceScore() {
        Random random = new Random();
        var num = String.valueOf(random.ints(1, 6)
                .findFirst()
                .getAsInt());

        setAliceScore(num);
        return num;
    }


}
