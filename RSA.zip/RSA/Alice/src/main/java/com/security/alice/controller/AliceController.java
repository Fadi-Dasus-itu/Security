package com.security.alice.controller;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.security.alice.model.ApiModel;
import com.security.alice.service.AES;
import com.security.alice.service.AliceService;
import com.security.alice.service.BobService;

@RestController
@RequestMapping("/Alice")
public class AliceController {

    private final AliceService aliceService;

    private final BobService bobService;

    private final AES AESService;

    @Autowired
    public AliceController(AliceService aliceService, BobService bobService, AES AESService) {
        this.aliceService = aliceService;
        this.bobService = bobService;
        this.AESService = AESService;
    }

    @GetMapping("/getAlicePublicKey")
    public ResponseEntity<byte[]> getAlicePublicKey() throws IOException {
        var aliceKey = aliceService.getPublicKey().getEncoded();
        return new ResponseEntity<>(aliceKey, HttpStatus.OK);
    }

    // Bob send a message to Alice (encrypted using Alice public key)
    @PostMapping("/sendEncryptedMessage")
    public ResponseEntity<String> sendEncryptedMessage(@RequestBody ApiModel apiModel) throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException, SignatureException {
        var message = aliceService.decryptMessage(apiModel.getEncryptedMessage());
        var validator = aliceService.verifySignature(apiModel, message);
        bobService.setBobScore(message);
        if (validator) {
            System.out.println("Bob digital signature is valid ");
            return new ResponseEntity<>("received", HttpStatus.OK);
        }

        return new ResponseEntity<>("the message has been tempered with", HttpStatus.UNAUTHORIZED);
    }

    @PostMapping("/publishBobPK")
    public ResponseEntity<?> publishBobPK(@RequestBody byte[] key) throws NoSuchAlgorithmException, InvalidKeySpecException {
        System.out.println("Bob public key is received");

        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(key);
        bobService.setPublicKey(keyFactory.generatePublic(publicKeySpec));
        PublicKey bobPK = bobService.getPublicKey();
        return new ResponseEntity<>("received", HttpStatus.OK);
    }

    @GetMapping("/getAliceDiceScore")
    public ResponseEntity<ApiModel> getAliceDiceScore() throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException, SignatureException {
        var score = aliceService.generateRandomDiceScore();
        System.out.println("Alice generated randomly:" + score);
        var encryptedMessage = aliceService.encryptMessage(score);
        var signature = aliceService.signTheMessage(score);
        ApiModel model = new ApiModel();
        model.setEncryptedMessage(encryptedMessage);
        model.setDigitalSignature(signature);

        return new ResponseEntity<>(model, HttpStatus.OK);
    }

    @PostMapping("/sendAESKey")
    public ResponseEntity<String> sendAESKey(@RequestBody ApiModel apiModel) throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException {
        var AESKey = aliceService.decryptMessage(apiModel.getEncryptedMessage());

        var bobEncryptedScore = bobService.getBobScore();
        var bobScore = this.AESService.decrypt(bobEncryptedScore, AESKey);
        bobService.setBobScore(bobScore);
        printTheWinner(aliceService.getAliceScore(),bobService.getBobScore());

        return new ResponseEntity<>("received", HttpStatus.OK);
    }

    private void printTheWinner(String aliceScore, String bobScore) {
        var aliceScoreInt = Integer.valueOf(aliceScore);
        var bobScoreInt = Integer.valueOf(bobScore);
        if (aliceScoreInt > bobScoreInt) {
            System.out.println("Alice Score is :" + aliceService.getAliceScore() + ", Bob Score is: " + bobService.getBobScore()+" the winner is Alice");
        } else if(aliceScoreInt < bobScoreInt){
            System.out.println("Alice Score is :" + aliceService.getAliceScore() + ", Bob Score is: " + bobService.getBobScore()+" the winner is Bob");
        }
        else{
            System.out.println("there is no winner for this round, please try again");
        }
    }
}
