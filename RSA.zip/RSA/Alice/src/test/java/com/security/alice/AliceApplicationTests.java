package com.security.alice;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.security.alice.model.Player;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)class AliceApplicationTests {

    @Autowired
    private TestRestTemplate restTemplate;

    private static final String URL = "http://localhost:8080/Bob/";

    @Test
    @DisplayName("Bob roll his dice successfully")
    void contextLoads() {
        // arrange
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(URL + "postEncryptedScore",
                new Player("Bob", "5"),
                String.class);

        int statusCode = responseEntity.getStatusCodeValue();
        String responseBody = responseEntity.getBody();
        assertEquals(responseBody, "Bob rolled his dice");
        assertEquals(HttpStatus.OK.value(), statusCode);
        assertNotNull(responseBody);


        ResponseEntity<Player> getResponseEntity = restTemplate.getForEntity(URL + "getPlayerScore?playerName="+"Bob",
                Player.class);
        var getResponseBody = getResponseEntity.getBody();
        assertEquals(getResponseBody.getPlayerName(), "Bob");
        assertEquals(getResponseBody.getDiceScore(), "5");
    }

}

